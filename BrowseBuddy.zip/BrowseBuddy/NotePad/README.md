<p align="center">
    <img alt="" height="80" src="">
  </a>
</p>
<h1 align="center">NotePad Extension</h1>

<div align="center">
  Notepad made using HTML, CSS AND JS.
</div>

<br />

<div align="center">
  <!-- Standard -->
  <a href="https://standardjs.com">
    <img src="https://img.shields.io/badge/code%20style-standard-brightgreen.svg?style=flat-square"
      alt="Standard" />
  </a>
</div>


## 📷 Screenshots

![ss1](./img/Screenshot%202022-04-22%20113100.png)


## ‎‍💻 Authors

- [@iamrahulmahato](https://www.github.com/iamrahulmahato)
## ⭐️ Show your support

Give a star if this project helped you!
