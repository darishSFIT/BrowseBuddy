# Pick The Color Extension:
> It's a **Color Picker Extension** where User can choose color as they want.

## Demo:


https://user-images.githubusercontent.com/77873383/168208026-459b54d4-f67b-46ed-85c9-6c717da24b18.mp4

