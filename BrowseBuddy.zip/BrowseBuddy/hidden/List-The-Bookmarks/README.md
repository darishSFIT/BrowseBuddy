## LIST THE BOOKMARKS

### AIM

The main aim of the project is create an extension that list the bookmarks

### PURPOSE

This project will help in having a separate extension that helps in listing out the bookmarks we have termed as our favourites

### DESCRIPTION

- Add popup html file that enables the extension format
- Included css and js file to function this project
- Include json file with all necessary add-ons

### SETUP INSTRUCTIONS

Go to Extensions in Google Chrome and Enable the Toggle button of Developer Mode to activate the extension

## AUTHOR

Prathima Kadari

