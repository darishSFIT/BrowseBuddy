Hello Floks!

I have created a "URL-shortner" chrome extention, which generates a short url link in place of the lengthy one.

#Applications:
One of the major use of this extention is:
Resume: lengthly url's take up a lot of space, using this extention would help you generate a short url to give you more space to mention and flaunt about your skills.

However the user can use it wherever they want.

I hope it benefits everyone using it!
 
